# CSE 333 Project
### By Stephen Gung

Initial startup credentials:
----------------------
Key: 
accountType
	_user_, *password*
----------------------
Guests
	_jdoe_, *pass1*
	_jsmith_, *pass1*
	_mfenix_, *pass1*
----------------------
Employee
	_bjamin_, *emp*
	_tclaire_, *emp*
----------------------
Manager
	_manager_, *123*
----------------------